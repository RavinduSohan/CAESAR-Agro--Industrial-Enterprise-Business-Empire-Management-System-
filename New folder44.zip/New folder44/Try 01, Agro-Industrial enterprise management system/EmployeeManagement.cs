﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Try_01__Agro_Industrial_enterprise_management_system
{
    public partial class EmployeeManagement : Form
    {
        public EmployeeManagement()
        {
            InitializeComponent();
            showemployee();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""F:\favo\New folder44\New folder\Agr-Industrial Enterprise Management System.mdf"";Integrated Security=True;Connect Timeout=30");

        private void showemployee()
        {
            con.Open();
            string Query = "Select * from [Employees Table]";
            SqlDataAdapter sda = new SqlDataAdapter(Query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            EmployeeManagementDGV.DataSource = ds.Tables[0];
            con.Close();
        }

        private void Reset()
        {
            EmployeeIdTextBox.Text = "";
            EmployeeNameTextBox.Text = "";
            ContactInfoTextBox.Text = "";
            DepartmentTextBox.Text = "";
            SalaryTextBox.Text = "";
            JobTitleTextBox.Text = "";
            PerformanceReviewDateTimePicker.Value= DateTimePicker.MinimumDateTime;
        }
        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void Form7_Load(object sender, EventArgs e)
        {

        }

        private void Savebtn_Click(object sender, EventArgs e)
        {
            if (EmployeeIdTextBox.Text==""|| EmployeeNameTextBox.Text==""|| ContactInfoTextBox.Text==""|| DepartmentTextBox.Text==""|| SalaryTextBox.Text==""|| JobTitleTextBox.Text==""|| PerformanceReviewDateTimePicker.Value == DateTimePicker.MinimumDateTime)
            {
                MessageBox.Show("Missing Info!");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Insert into [Employees Table] (EmployeeId,EmployeeName,ContactInfo,Department,Salary,JobTitle,PerformanceReview) values (@EmployeeId,@EmployeeName,@ContactInfo,@Department,@Salary,@JobTitle,@PerformanceReview)", con);
                    cmd.Parameters.AddWithValue("@EmployeeId", EmployeeIdTextBox.Text);
                    cmd.Parameters.AddWithValue("@EmployeeName", EmployeeNameTextBox.Text);
                    cmd.Parameters.AddWithValue("@ContactInfo", ContactInfoTextBox.Text);
                    cmd.Parameters.AddWithValue("@Department", DepartmentTextBox.Text);
                    cmd.Parameters.AddWithValue("@Salary", SalaryTextBox.Text);
                    cmd.Parameters.AddWithValue("@JobTitle", JobTitleTextBox.Text);
                    cmd.Parameters.AddWithValue("@PerformanceReview", PerformanceReviewDateTimePicker.Value);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Added!");
                    con.Close();
                    showemployee();
                    Reset();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
               
            }
        }
        
        int key = 0;

        private void EmployeeManagementDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                // Assuming SupplierID is stored in the first column (index 0) of the DataGridView
                string EmployeeID = EmployeeManagementDGV.Rows[e.RowIndex].Cells[0].Value.ToString();
                string EmployeeName = EmployeeManagementDGV.Rows[e.RowIndex].Cells[1].Value.ToString();
                string ContactInfo = EmployeeManagementDGV.Rows[e.RowIndex].Cells[2].Value.ToString();
                string Department = EmployeeManagementDGV.Rows[e.RowIndex].Cells[3].Value.ToString();
                string JobTitle = EmployeeManagementDGV.Rows[e.RowIndex].Cells[4].Value.ToString();
             
                string salary = EmployeeManagementDGV.Rows[e.RowIndex].Cells[6].Value.ToString();
                string primarykey = EmployeeManagementDGV.Rows[e.RowIndex].Cells[8].Value.ToString();



                EmployeeIdTextBox.Text = primarykey;
                EmployeeNameTextBox.Text = EmployeeName;
                ContactInfoTextBox.Text = ContactInfo;
                DepartmentTextBox.Text = Department;
                JobTitleTextBox.Text = JobTitle;
                SalaryTextBox.Text = salary;
                primarykeyTextBox.Text = EmployeeID;

                
              

            }
        }
        /*
        private void ClearEmployeeDetails()
        {
            EmployeeIdTextBox.Clear();
            EmployeeNameTextBox.Clear();
            ContactInfoTextBox.Clear();
            DepartmentTextBox.Clear();
            SalaryTextBox.Text  = "";
            JobTitleTextBox.Clear();
        }  */
        

        private void Editbtn_Click(object sender, EventArgs e)
        {
            if (EmployeeIdTextBox.Text == "" || EmployeeNameTextBox.Text == "" || ContactInfoTextBox.Text == "" || DepartmentTextBox.Text == "" || SalaryTextBox.Text == "" || JobTitleTextBox.Text == ""|| PerformanceReviewDateTimePicker.Value == DateTimePicker.MinimumDateTime)
            {
                MessageBox.Show("Missing Info!");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Update [Employees Table] set EmployeeId=@EmployeeId,EmployeeName=@EmployeeName,ContactInfo=@ContactInfo,Department=@Department,Salary=@Salary,JobTitle=@JobTitle,PerformanceReview=@PerformanceReview Where EEmployeeID=@primaryKey", con);
                    cmd.Parameters.AddWithValue("@EmployeeId", EmployeeIdTextBox.Text);
                    cmd.Parameters.AddWithValue("@EmployeeName", EmployeeNameTextBox.Text);
                    cmd.Parameters.AddWithValue("@ContactInfo", ContactInfoTextBox.Text);
                    cmd.Parameters.AddWithValue("@Department", DepartmentTextBox.Text);
                    cmd.Parameters.AddWithValue("@Salary", SalaryTextBox.Text);
                    cmd.Parameters.AddWithValue("@JobTitle", JobTitleTextBox.Text);
                    cmd.Parameters.AddWithValue("@PerformanceReview", PerformanceReviewDateTimePicker.Value);
                    cmd.Parameters.AddWithValue("@primaryKey", primarykeyTextBox.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Updated!");
                    con.Close();
                    showemployee();
                    Reset();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void Deletebtn_Click(object sender, EventArgs e)
        {
            if (EmployeeIdTextBox.Text == "" || EmployeeNameTextBox.Text == "" || ContactInfoTextBox.Text == "" || DepartmentTextBox.Text == "" || SalaryTextBox.Text == "" || JobTitleTextBox.Text == "" || PerformanceReviewDateTimePicker.Value == DateTimePicker.MinimumDateTime)
            {
                MessageBox.Show("Missing Info!");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Delete from [Employees Table] Where EEmployeeID=@primaryKey", con);
                    cmd.Parameters.AddWithValue("@primaryKey", primarykeyTextBox.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Deleted!");
                    con.Close();
                    showemployee();
                    Reset();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Home obj = new Home();
            obj.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            InventoryManagement obj = new InventoryManagement();
            obj.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            SalesandMarketing obj = new SalesandMarketing();
            obj.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            CropManagement obj = new CropManagement();
            obj.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            SupplyChainManagement obj = new SupplyChainManagement();
            obj.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            FinancialAnalysis obj = new FinancialAnalysis();
            obj.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            EmployeeManagement obj = new EmployeeManagement();
            obj.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            QualityControl obj = new QualityControl();
            obj.Show();
            this.Hide();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            EquipmentMaintenance obj = new EquipmentMaintenance();
            obj.Show();
            this.Hide();
        }

        private void SalaryTextBox_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {
            Login obj= new Login();
            obj.Show();
            this.Hide();
        }
    }
}
