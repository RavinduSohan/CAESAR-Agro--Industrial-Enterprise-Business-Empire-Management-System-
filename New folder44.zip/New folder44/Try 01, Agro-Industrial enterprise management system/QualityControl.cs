﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Try_01__Agro_Industrial_enterprise_management_system
{
    public partial class QualityControl : Form
    {
        public QualityControl()
        {
            InitializeComponent();
            showQuality();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""F:\favo\New folder44\New folder\Agr-Industrial Enterprise Management System.mdf"";Integrated Security=True;Connect Timeout=30");

        private void showQuality()
        {
            con.Open();
            string Query = "Select * from [Inspection Table]";
            SqlDataAdapter sda = new SqlDataAdapter(Query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            QualityControlDGV.DataSource = ds.Tables[0];
            con.Close();
        }
        private void Reset()
        {
            InspectionIdTextBox.Text = "";
            ProductIdTextBox.Text = "";
            InspectorNameTextBox.Text = "";
            QualityRatingTextBox.Text = "";
            DefectDetailsTextBox.Text = "";
            CorrectiveActionTakenTextBox.Text = "";
            InspectionDateDateTimePicker.Value= DateTimePicker.MinimumDateTime;
        }


        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void Savebtn_Click(object sender, EventArgs e)
        {
            if (InspectionIdTextBox.Text==""|| ProductIdTextBox.Text==""|| InspectorNameTextBox.Text==""|| QualityRatingTextBox.Text==""|| DefectDetailsTextBox.Text==""|| CorrectiveActionTakenTextBox.Text==""|| InspectionDateDateTimePicker.Value == DateTimePicker.MinimumDateTime)
            {
                MessageBox.Show("Missing Info!");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Insert into [Inspection Table] (InspectionId,ProductId,InspectorName,QualityRating,DefectDetails,CorrectiveActionTaken,InspectionDate) Values (@InspectionId,@ProductId,@InspectorName,@QualityRating,@DefectDetails,@CorrectiveActionTaken,@InspectionDate)", con);
                    cmd.Parameters.AddWithValue("@InspectionId", InspectionIdTextBox.Text);
                    cmd.Parameters.AddWithValue("@ProductId", ProductIdTextBox.Text);
                    cmd.Parameters.AddWithValue("@InspectorName", InspectorNameTextBox.Text);
                    cmd.Parameters.AddWithValue("@QualityRating", QualityRatingTextBox.Text);
                    cmd.Parameters.AddWithValue("@DefectDetails", DefectDetailsTextBox.Text);
                    cmd.Parameters.AddWithValue("@CorrectiveActionTaken", CorrectiveActionTakenTextBox.Text);
                    cmd.Parameters.AddWithValue("@InspectionDate", InspectionDateDateTimePicker.Value);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Added!");
                    con.Close();
                    showQuality();
                    Reset();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                
            }
        }

        int key = 0;
        private void QualityControlDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                // Assuming SupplierID is stored in the first column (index 0) of the DataGridView
                string InspectionId = QualityControlDGV.Rows[e.RowIndex].Cells[0].Value.ToString();
                string ProductId = QualityControlDGV.Rows[e.RowIndex].Cells[1].Value.ToString();
                string InspectorName = QualityControlDGV.Rows[e.RowIndex].Cells[3].Value.ToString();
                string QualityRating = QualityControlDGV.Rows[e.RowIndex].Cells[4].Value.ToString();
                string DefectDetails = QualityControlDGV.Rows[e.RowIndex].Cells[5].Value.ToString();
                string CorrectiveActionTaken = QualityControlDGV.Rows[e.RowIndex].Cells[6].Value.ToString();
                string InspectionDate = QualityControlDGV.Rows[e.RowIndex].Cells[2].Value.ToString();
                string IInspectionId = QualityControlDGV.Rows[e.RowIndex].Cells[7].Value.ToString();



                InspectionIdTextBox.Text = IInspectionId;
                ProductIdTextBox.Text = ProductId;
                InspectorNameTextBox.Text = InspectorName;
                QualityRatingTextBox.Text = QualityRating;
                DefectDetailsTextBox.Text = DefectDetails;
                CorrectiveActionTakenTextBox.Text = CorrectiveActionTaken;
                InspectionDateDateTimePicker.Value = DateTime.Parse(InspectionDate);
                primaryKeyTextBox.Text = InspectionId;

               


            }
        }

        private void Editbtn_Click(object sender, EventArgs e)
        {
            if (InspectionIdTextBox.Text == "" || ProductIdTextBox.Text == "" || InspectorNameTextBox.Text == "" || QualityRatingTextBox.Text == "" || DefectDetailsTextBox.Text == "" || CorrectiveActionTakenTextBox.Text == ""|| InspectionDateDateTimePicker.Value == DateTimePicker.MinimumDateTime)
            {
                MessageBox.Show("Missing Info!");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Update [Inspection Table] set InspectionId= @InspectionId,ProductId=@ProductId,InspectorName=@InspectorName,QualityRating=@QualityRating,DefectDetails=@DefectDetails,CorrectiveActionTaken=@CorrectiveActionTaken,InspectionDate=@InspectionDate Where IInspectionId=@primaryKey", con);
                    cmd.Parameters.AddWithValue("@InspectionId", InspectionIdTextBox.Text);
                    cmd.Parameters.AddWithValue("@ProductId", ProductIdTextBox.Text);
                    cmd.Parameters.AddWithValue("@InspectorName", InspectorNameTextBox.Text);
                    cmd.Parameters.AddWithValue("@QualityRating", QualityRatingTextBox.Text);
                    cmd.Parameters.AddWithValue("@DefectDetails", DefectDetailsTextBox.Text);
                    cmd.Parameters.AddWithValue("@CorrectiveActionTaken", CorrectiveActionTakenTextBox.Text);
                    cmd.Parameters.AddWithValue("@InspectionDate", InspectionDateDateTimePicker.Value);
                    cmd.Parameters.AddWithValue("@primaryKey", primaryKeyTextBox.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Updated!");
                    con.Close();
                    showQuality();
                    Reset();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void Deletebtn_Click(object sender, EventArgs e)
        {
            if (InspectionIdTextBox.Text == "" || ProductIdTextBox.Text == "" || InspectorNameTextBox.Text == "" || QualityRatingTextBox.Text == "" || DefectDetailsTextBox.Text == "" || CorrectiveActionTakenTextBox.Text == "" || InspectionDateDateTimePicker.Value == DateTimePicker.MinimumDateTime)
            {
                MessageBox.Show("Missing Info!");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Delete from [Inspection Table] Where IInspectionId=@primaryKey", con);
                    cmd.Parameters.AddWithValue("@primaryKey", primaryKeyTextBox.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Deleted!");
                    con.Close();
                    showQuality();
                    Reset();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Home obj = new Home();
            obj.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            InventoryManagement obj = new InventoryManagement();
            obj.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            SalesandMarketing obj = new SalesandMarketing();
            obj.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            CropManagement obj = new CropManagement();
            obj.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            SupplyChainManagement obj = new SupplyChainManagement();
            obj.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            FinancialAnalysis obj = new FinancialAnalysis();
            obj.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            EmployeeManagement obj = new EmployeeManagement();
            obj.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            QualityControl obj = new QualityControl();
            obj.Show();
            this.Hide();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            EquipmentMaintenance obj = new EquipmentMaintenance();
            obj.Show();
            this.Hide();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            Login obj= new Login();
            obj.Show();
            this.Hide();
        }
    }
}
