﻿namespace Try_01__Agro_Industrial_enterprise_management_system
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.label24 = new System.Windows.Forms.Label();
            this.Inventorieslbl = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.Financiallbl = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.Equipmentslbl = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.Employeeslbl = new System.Windows.Forms.Label();
            this.Inspectionslbl = new System.Windows.Forms.Label();
            this.Cropslbl = new System.Windows.Forms.Label();
            this.Customerslbl = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.Profitlbl = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.Salarieslbl = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.label17 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Totalsaleslbl = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Budgetlbl = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            this.panel7.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            this.panel8.SuspendLayout();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            this.panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Location = new System.Drawing.Point(170, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(7, 615);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Image = global::Try_01__Agro_Industrial_enterprise_management_system.Properties.Resources.caesar_agro;
            this.pictureBox1.Location = new System.Drawing.Point(7, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(49, 45);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(45)))), ((int)(((byte)(22)))));
            this.panel2.Controls.Add(this.pictureBox20);
            this.panel2.Controls.Add(this.pictureBox15);
            this.panel2.Controls.Add(this.pictureBox23);
            this.panel2.Controls.Add(this.label24);
            this.panel2.Controls.Add(this.Inventorieslbl);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.Financiallbl);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.Equipmentslbl);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.pictureBox14);
            this.panel2.Controls.Add(this.pictureBox13);
            this.panel2.Controls.Add(this.pictureBox12);
            this.panel2.Controls.Add(this.pictureBox19);
            this.panel2.Controls.Add(this.Employeeslbl);
            this.panel2.Controls.Add(this.Inspectionslbl);
            this.panel2.Controls.Add(this.Cropslbl);
            this.panel2.Controls.Add(this.Customerslbl);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Location = new System.Drawing.Point(739, 123);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(192, 494);
            this.panel2.TabIndex = 22;
            // 
            // pictureBox20
            // 
            this.pictureBox20.BackColor = System.Drawing.Color.White;
            this.pictureBox20.Image = global::Try_01__Agro_Industrial_enterprise_management_system.Properties.Resources.ptt__14_;
            this.pictureBox20.Location = new System.Drawing.Point(12, 425);
            this.pictureBox20.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(40, 37);
            this.pictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox20.TabIndex = 161;
            this.pictureBox20.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.BackColor = System.Drawing.Color.White;
            this.pictureBox15.Image = global::Try_01__Agro_Industrial_enterprise_management_system.Properties.Resources.ptt__6_;
            this.pictureBox15.Location = new System.Drawing.Point(12, 363);
            this.pictureBox15.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(40, 37);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox15.TabIndex = 161;
            this.pictureBox15.TabStop = false;
            // 
            // pictureBox23
            // 
            this.pictureBox23.BackColor = System.Drawing.Color.White;
            this.pictureBox23.Image = global::Try_01__Agro_Industrial_enterprise_management_system.Properties.Resources.ptt__3_;
            this.pictureBox23.Location = new System.Drawing.Point(12, 303);
            this.pictureBox23.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(40, 37);
            this.pictureBox23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox23.TabIndex = 161;
            this.pictureBox23.TabStop = false;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(197)))), ((int)(((byte)(154)))));
            this.label24.Location = new System.Drawing.Point(59, 425);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(79, 18);
            this.label24.TabIndex = 174;
            this.label24.Text = "Inventories";
            // 
            // Inventorieslbl
            // 
            this.Inventorieslbl.AutoSize = true;
            this.Inventorieslbl.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Inventorieslbl.ForeColor = System.Drawing.Color.White;
            this.Inventorieslbl.Location = new System.Drawing.Point(59, 443);
            this.Inventorieslbl.Name = "Inventorieslbl";
            this.Inventorieslbl.Size = new System.Drawing.Size(72, 19);
            this.Inventorieslbl.TabIndex = 172;
            this.Inventorieslbl.Text = "Statistics";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(197)))), ((int)(((byte)(154)))));
            this.label15.Location = new System.Drawing.Point(59, 363);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(66, 18);
            this.label15.TabIndex = 171;
            this.label15.Text = "Financial";
            // 
            // Financiallbl
            // 
            this.Financiallbl.AutoSize = true;
            this.Financiallbl.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Financiallbl.ForeColor = System.Drawing.Color.White;
            this.Financiallbl.Location = new System.Drawing.Point(59, 385);
            this.Financiallbl.Name = "Financiallbl";
            this.Financiallbl.Size = new System.Drawing.Size(72, 19);
            this.Financiallbl.TabIndex = 169;
            this.Financiallbl.Text = "Statistics";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(197)))), ((int)(((byte)(154)))));
            this.label13.Location = new System.Drawing.Point(59, 304);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(86, 18);
            this.label13.TabIndex = 168;
            this.label13.Text = "Equipments";
            // 
            // Equipmentslbl
            // 
            this.Equipmentslbl.AutoSize = true;
            this.Equipmentslbl.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Equipmentslbl.ForeColor = System.Drawing.Color.White;
            this.Equipmentslbl.Location = new System.Drawing.Point(59, 326);
            this.Equipmentslbl.Name = "Equipmentslbl";
            this.Equipmentslbl.Size = new System.Drawing.Size(72, 19);
            this.Equipmentslbl.TabIndex = 166;
            this.Equipmentslbl.Text = "Statistics";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(197)))), ((int)(((byte)(154)))));
            this.label22.Location = new System.Drawing.Point(59, 244);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(82, 18);
            this.label22.TabIndex = 165;
            this.label22.Text = "Employees";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(197)))), ((int)(((byte)(154)))));
            this.label21.Location = new System.Drawing.Point(59, 183);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(83, 18);
            this.label21.TabIndex = 164;
            this.label21.Text = "Inspections";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(197)))), ((int)(((byte)(154)))));
            this.label20.Location = new System.Drawing.Point(59, 119);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(49, 18);
            this.label20.TabIndex = 163;
            this.label20.Text = "Crops";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(197)))), ((int)(((byte)(154)))));
            this.label12.Location = new System.Drawing.Point(59, 55);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(82, 18);
            this.label12.TabIndex = 162;
            this.label12.Text = "Customers";
            // 
            // pictureBox14
            // 
            this.pictureBox14.BackColor = System.Drawing.Color.White;
            this.pictureBox14.Image = global::Try_01__Agro_Industrial_enterprise_management_system.Properties.Resources.ptt__5_;
            this.pictureBox14.Location = new System.Drawing.Point(12, 244);
            this.pictureBox14.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(40, 37);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox14.TabIndex = 161;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.BackColor = System.Drawing.Color.White;
            this.pictureBox13.Image = global::Try_01__Agro_Industrial_enterprise_management_system.Properties.Resources.ptt__4_;
            this.pictureBox13.Location = new System.Drawing.Point(12, 183);
            this.pictureBox13.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(40, 37);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox13.TabIndex = 161;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.BackColor = System.Drawing.Color.White;
            this.pictureBox12.Image = global::Try_01__Agro_Industrial_enterprise_management_system.Properties.Resources.ptt__11_;
            this.pictureBox12.Location = new System.Drawing.Point(12, 119);
            this.pictureBox12.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(40, 37);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox12.TabIndex = 161;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox19
            // 
            this.pictureBox19.BackColor = System.Drawing.Color.White;
            this.pictureBox19.Image = global::Try_01__Agro_Industrial_enterprise_management_system.Properties.Resources.ptt__12_;
            this.pictureBox19.Location = new System.Drawing.Point(12, 58);
            this.pictureBox19.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(40, 37);
            this.pictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox19.TabIndex = 145;
            this.pictureBox19.TabStop = false;
            // 
            // Employeeslbl
            // 
            this.Employeeslbl.AutoSize = true;
            this.Employeeslbl.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Employeeslbl.ForeColor = System.Drawing.Color.White;
            this.Employeeslbl.Location = new System.Drawing.Point(59, 263);
            this.Employeeslbl.Name = "Employeeslbl";
            this.Employeeslbl.Size = new System.Drawing.Size(72, 19);
            this.Employeeslbl.TabIndex = 30;
            this.Employeeslbl.Text = "Statistics";
            // 
            // Inspectionslbl
            // 
            this.Inspectionslbl.AutoSize = true;
            this.Inspectionslbl.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Inspectionslbl.ForeColor = System.Drawing.Color.White;
            this.Inspectionslbl.Location = new System.Drawing.Point(59, 202);
            this.Inspectionslbl.Name = "Inspectionslbl";
            this.Inspectionslbl.Size = new System.Drawing.Size(72, 19);
            this.Inspectionslbl.TabIndex = 28;
            this.Inspectionslbl.Text = "Statistics";
            // 
            // Cropslbl
            // 
            this.Cropslbl.AutoSize = true;
            this.Cropslbl.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cropslbl.ForeColor = System.Drawing.Color.White;
            this.Cropslbl.Location = new System.Drawing.Point(59, 138);
            this.Cropslbl.Name = "Cropslbl";
            this.Cropslbl.Size = new System.Drawing.Size(72, 19);
            this.Cropslbl.TabIndex = 26;
            this.Cropslbl.Text = "Statistics";
            // 
            // Customerslbl
            // 
            this.Customerslbl.AutoSize = true;
            this.Customerslbl.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Customerslbl.ForeColor = System.Drawing.Color.White;
            this.Customerslbl.Location = new System.Drawing.Point(59, 77);
            this.Customerslbl.Name = "Customerslbl";
            this.Customerslbl.Size = new System.Drawing.Size(72, 19);
            this.Customerslbl.TabIndex = 25;
            this.Customerslbl.Text = "Statistics";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(197)))), ((int)(((byte)(154)))));
            this.label11.Location = new System.Drawing.Point(3, 14);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(87, 23);
            this.label11.TabIndex = 24;
            this.label11.Text = "Statistics";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(197)))), ((int)(((byte)(154)))));
            this.label16.Location = new System.Drawing.Point(280, 24);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(396, 23);
            this.label16.TabIndex = 25;
            this.label16.Text = "CAESAR Agro-Industrial Enterprise pvt(Ltd)";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(138)))), ((int)(((byte)(55)))));
            this.panel7.Controls.Add(this.Profitlbl);
            this.panel7.Controls.Add(this.label18);
            this.panel7.Controls.Add(this.panel9);
            this.panel7.Location = new System.Drawing.Point(189, 345);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(180, 76);
            this.panel7.TabIndex = 27;
            // 
            // Profitlbl
            // 
            this.Profitlbl.AutoSize = true;
            this.Profitlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Profitlbl.ForeColor = System.Drawing.Color.White;
            this.Profitlbl.Location = new System.Drawing.Point(48, 36);
            this.Profitlbl.Name = "Profitlbl";
            this.Profitlbl.Size = new System.Drawing.Size(78, 18);
            this.Profitlbl.TabIndex = 34;
            this.Profitlbl.Text = "Statistics";
            this.Profitlbl.Click += new System.EventHandler(this.Profitlbl_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(237)))), ((int)(((byte)(154)))));
            this.label18.Location = new System.Drawing.Point(48, 18);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(43, 16);
            this.label18.TabIndex = 33;
            this.label18.Text = "Profit";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.Controls.Add(this.pictureBox16);
            this.panel9.Location = new System.Drawing.Point(6, 15);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(36, 37);
            this.panel9.TabIndex = 32;
            // 
            // pictureBox16
            // 
            this.pictureBox16.BackColor = System.Drawing.Color.White;
            this.pictureBox16.Image = global::Try_01__Agro_Industrial_enterprise_management_system.Properties.Resources.ptt__12_;
            this.pictureBox16.Location = new System.Drawing.Point(-2, 0);
            this.pictureBox16.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(40, 37);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox16.TabIndex = 162;
            this.pictureBox16.TabStop = false;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(138)))), ((int)(((byte)(55)))));
            this.panel8.Controls.Add(this.Salarieslbl);
            this.panel8.Controls.Add(this.label19);
            this.panel8.Controls.Add(this.panel10);
            this.panel8.Location = new System.Drawing.Point(553, 345);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(180, 76);
            this.panel8.TabIndex = 28;
            // 
            // Salarieslbl
            // 
            this.Salarieslbl.AutoSize = true;
            this.Salarieslbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Salarieslbl.ForeColor = System.Drawing.Color.White;
            this.Salarieslbl.Location = new System.Drawing.Point(45, 36);
            this.Salarieslbl.Name = "Salarieslbl";
            this.Salarieslbl.Size = new System.Drawing.Size(78, 18);
            this.Salarieslbl.TabIndex = 35;
            this.Salarieslbl.Text = "Statistics";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(237)))), ((int)(((byte)(154)))));
            this.label19.Location = new System.Drawing.Point(45, 15);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(65, 16);
            this.label19.TabIndex = 34;
            this.label19.Text = "Salaries";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.Controls.Add(this.pictureBox24);
            this.panel10.Location = new System.Drawing.Point(3, 15);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(36, 37);
            this.panel10.TabIndex = 32;
            // 
            // pictureBox24
            // 
            this.pictureBox24.BackColor = System.Drawing.Color.White;
            this.pictureBox24.Image = global::Try_01__Agro_Industrial_enterprise_management_system.Properties.Resources.ptt__6_;
            this.pictureBox24.Location = new System.Drawing.Point(-3, 2);
            this.pictureBox24.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(40, 37);
            this.pictureBox24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox24.TabIndex = 162;
            this.pictureBox24.TabStop = false;
            // 
            // pictureBox18
            // 
            this.pictureBox18.Image = global::Try_01__Agro_Industrial_enterprise_management_system.Properties.Resources.caesar_agro;
            this.pictureBox18.Location = new System.Drawing.Point(273, 0);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(247, 214);
            this.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox18.TabIndex = 27;
            this.pictureBox18.TabStop = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(197)))), ((int)(((byte)(154)))));
            this.label17.Location = new System.Drawing.Point(29, 34);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(222, 126);
            this.label17.TabIndex = 26;
            this.label17.Text = "CAESAR Agro-Industrial\r\nEnterprise:\r\n\r\nSee the invisible,\r\nFeel the intangible,\r\n" +
    "and achieve the impossible.";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(45)))), ((int)(((byte)(22)))));
            this.panel11.Controls.Add(this.label17);
            this.panel11.Controls.Add(this.pictureBox18);
            this.panel11.Location = new System.Drawing.Point(195, 105);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(527, 217);
            this.panel11.TabIndex = 29;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.SystemColors.Control;
            this.panel12.Location = new System.Drawing.Point(51, 93);
            this.panel12.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(122, 3);
            this.panel12.TabIndex = 160;
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackColor = System.Drawing.Color.White;
            this.pictureBox11.Image = global::Try_01__Agro_Industrial_enterprise_management_system.Properties.Resources.ptt__3_;
            this.pictureBox11.Location = new System.Drawing.Point(7, 474);
            this.pictureBox11.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(40, 37);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox11.TabIndex = 156;
            this.pictureBox11.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(197)))), ((int)(((byte)(154)))));
            this.label10.Location = new System.Drawing.Point(54, 476);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(99, 38);
            this.label10.TabIndex = 157;
            this.label10.Text = "Equipment \r\nMaintenance";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(197)))), ((int)(((byte)(154)))));
            this.label1.Location = new System.Drawing.Point(54, 72);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 19);
            this.label1.TabIndex = 141;
            this.label1.Text = "Home";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.Image = global::Try_01__Agro_Industrial_enterprise_management_system.Properties.Resources.ptt__13_;
            this.pictureBox2.Location = new System.Drawing.Point(7, 53);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(40, 37);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 140;
            this.pictureBox2.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(197)))), ((int)(((byte)(154)))));
            this.label2.Location = new System.Drawing.Point(54, 110);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 38);
            this.label2.TabIndex = 143;
            this.label2.Text = "Inventory\r\n Management";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.White;
            this.pictureBox3.Image = global::Try_01__Agro_Industrial_enterprise_management_system.Properties.Resources.ptt__14_;
            this.pictureBox3.Location = new System.Drawing.Point(7, 105);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(40, 37);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 142;
            this.pictureBox3.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(197)))), ((int)(((byte)(154)))));
            this.label3.Location = new System.Drawing.Point(54, 216);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 38);
            this.label3.TabIndex = 147;
            this.label3.Text = "Crop \r\nManagement";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.White;
            this.pictureBox4.Image = global::Try_01__Agro_Industrial_enterprise_management_system.Properties.Resources.ptt__11_;
            this.pictureBox4.Location = new System.Drawing.Point(7, 213);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(40, 37);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 146;
            this.pictureBox4.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(197)))), ((int)(((byte)(154)))));
            this.label4.Location = new System.Drawing.Point(54, 164);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 38);
            this.label4.TabIndex = 145;
            this.label4.Text = "Sales and \r\nMarketing";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.White;
            this.pictureBox5.Image = global::Try_01__Agro_Industrial_enterprise_management_system.Properties.Resources.ptt__12_;
            this.pictureBox5.Location = new System.Drawing.Point(7, 160);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(40, 37);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 144;
            this.pictureBox5.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(197)))), ((int)(((byte)(154)))));
            this.label9.Location = new System.Drawing.Point(54, 533);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 19);
            this.label9.TabIndex = 159;
            this.label9.Text = "Logout";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackColor = System.Drawing.Color.White;
            this.pictureBox10.Image = global::Try_01__Agro_Industrial_enterprise_management_system.Properties.Resources.ptt__1_;
            this.pictureBox10.Location = new System.Drawing.Point(7, 530);
            this.pictureBox10.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(40, 37);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox10.TabIndex = 158;
            this.pictureBox10.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(197)))), ((int)(((byte)(154)))));
            this.label7.Location = new System.Drawing.Point(54, 425);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 38);
            this.label7.TabIndex = 155;
            this.label7.Text = "Quality \r\nControl";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.White;
            this.pictureBox8.Image = global::Try_01__Agro_Industrial_enterprise_management_system.Properties.Resources.ptt__4_;
            this.pictureBox8.Location = new System.Drawing.Point(7, 422);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(40, 37);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 154;
            this.pictureBox8.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(197)))), ((int)(((byte)(154)))));
            this.label8.Location = new System.Drawing.Point(54, 375);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(102, 38);
            this.label8.TabIndex = 153;
            this.label8.Text = "Employee \r\nManagement";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.White;
            this.pictureBox9.Image = global::Try_01__Agro_Industrial_enterprise_management_system.Properties.Resources.ptt__5_;
            this.pictureBox9.Location = new System.Drawing.Point(7, 370);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(40, 37);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 152;
            this.pictureBox9.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(197)))), ((int)(((byte)(154)))));
            this.label5.Location = new System.Drawing.Point(54, 321);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 38);
            this.label5.TabIndex = 151;
            this.label5.Text = "Financial \r\nAnalysis";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.White;
            this.pictureBox6.Image = global::Try_01__Agro_Industrial_enterprise_management_system.Properties.Resources.ptt__6_;
            this.pictureBox6.Location = new System.Drawing.Point(7, 317);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(40, 37);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 150;
            this.pictureBox6.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(197)))), ((int)(((byte)(154)))));
            this.label6.Location = new System.Drawing.Point(54, 265);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(102, 38);
            this.label6.TabIndex = 149;
            this.label6.Text = "SupplyChain \r\nManagement";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.White;
            this.pictureBox7.Image = global::Try_01__Agro_Industrial_enterprise_management_system.Properties.Resources.ptt__9_;
            this.pictureBox7.Location = new System.Drawing.Point(7, 265);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(40, 37);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 148;
            this.pictureBox7.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(138)))), ((int)(((byte)(55)))));
            this.panel3.Controls.Add(this.Totalsaleslbl);
            this.panel3.Controls.Add(this.label23);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(189, 476);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(180, 76);
            this.panel3.TabIndex = 161;
            // 
            // Totalsaleslbl
            // 
            this.Totalsaleslbl.AutoSize = true;
            this.Totalsaleslbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Totalsaleslbl.ForeColor = System.Drawing.Color.White;
            this.Totalsaleslbl.Location = new System.Drawing.Point(48, 36);
            this.Totalsaleslbl.Name = "Totalsaleslbl";
            this.Totalsaleslbl.Size = new System.Drawing.Size(78, 18);
            this.Totalsaleslbl.TabIndex = 34;
            this.Totalsaleslbl.Text = "Statistics";
            this.Totalsaleslbl.Click += new System.EventHandler(this.Totalsaleslbl_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(237)))), ((int)(((byte)(154)))));
            this.label23.Location = new System.Drawing.Point(48, 18);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(87, 16);
            this.label23.TabIndex = 33;
            this.label23.Text = "Total Sales";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.pictureBox21);
            this.panel4.Location = new System.Drawing.Point(6, 15);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(36, 37);
            this.panel4.TabIndex = 32;
            // 
            // pictureBox21
            // 
            this.pictureBox21.Image = global::Try_01__Agro_Industrial_enterprise_management_system.Properties.Resources.ptt__7_;
            this.pictureBox21.Location = new System.Drawing.Point(0, 3);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(32, 34);
            this.pictureBox21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox21.TabIndex = 23;
            this.pictureBox21.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(138)))), ((int)(((byte)(55)))));
            this.panel5.Controls.Add(this.Budgetlbl);
            this.panel5.Controls.Add(this.label26);
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Location = new System.Drawing.Point(556, 476);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(180, 76);
            this.panel5.TabIndex = 35;
            // 
            // Budgetlbl
            // 
            this.Budgetlbl.AutoSize = true;
            this.Budgetlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Budgetlbl.ForeColor = System.Drawing.Color.White;
            this.Budgetlbl.Location = new System.Drawing.Point(48, 36);
            this.Budgetlbl.Name = "Budgetlbl";
            this.Budgetlbl.Size = new System.Drawing.Size(78, 18);
            this.Budgetlbl.TabIndex = 34;
            this.Budgetlbl.Text = "Statistics";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(237)))), ((int)(((byte)(154)))));
            this.label26.Location = new System.Drawing.Point(48, 18);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(56, 16);
            this.label26.TabIndex = 33;
            this.label26.Text = "Budget";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Controls.Add(this.pictureBox17);
            this.panel6.Location = new System.Drawing.Point(6, 15);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(36, 37);
            this.panel6.TabIndex = 32;
            // 
            // pictureBox17
            // 
            this.pictureBox17.BackColor = System.Drawing.Color.White;
            this.pictureBox17.Image = global::Try_01__Agro_Industrial_enterprise_management_system.Properties.Resources.ptt__4_;
            this.pictureBox17.Location = new System.Drawing.Point(-2, 0);
            this.pictureBox17.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(40, 37);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox17.TabIndex = 162;
            this.pictureBox17.TabStop = false;
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImage = global::Try_01__Agro_Industrial_enterprise_management_system.Properties.Resources.volkanovski;
            this.ClientSize = new System.Drawing.Size(943, 616);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label Customerslbl;
        private System.Windows.Forms.Label Employeeslbl;
        private System.Windows.Forms.Label Inspectionslbl;
        private System.Windows.Forms.Label Cropslbl;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label Profitlbl;
        private System.Windows.Forms.Label Salarieslbl;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label Inventorieslbl;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label Financiallbl;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label Equipmentslbl;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label Totalsaleslbl;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label Budgetlbl;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.PictureBox pictureBox17;
    }
}

