﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Try_01__Agro_Industrial_enterprise_management_system
{
    public partial class SalesandMarketing : Form
    {
        public SalesandMarketing()
        {
            InitializeComponent();
            showsales();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""F:\favo\New folder44\New folder\Agr-Industrial Enterprise Management System.mdf"";Integrated Security=True;Connect Timeout=30");
       
        private void showsales()
        {
            con.Open();
            string Query = "Select * from [Sales Table]";
            SqlDataAdapter sda = new SqlDataAdapter(Query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            SalesandMarketingDGV.DataSource = ds.Tables[0];
            con.Close();
        }

        private void Reset()
        {
            CustomerIdtextbox.Text = "";
            CustomerNametextbox.Text = "";
            ContactInfotextbox.Text = "";
            SalesorderIdTextBox.Text="";
            QuantitySoldTextBox.Text = "";
            UnitPriceTextBox.Text = "";
            TotalSalesAmountTextBox.Text = "";
            ProductIdTextBox.Text="";
            MarketingCampaignDetailsTextBox.Text = "";
            SalesDateDateTimePicker.Value = DateTimePicker.MinimumDateTime;
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Deletebtn_Click(object sender, EventArgs e)
        {
            if (CustomerIdtextbox.Text == "" || CustomerNametextbox.Text == "" || ContactInfotextbox.Text == "" || SalesorderIdTextBox.Text == "" || QuantitySoldTextBox.Text == ""|| UnitPriceTextBox.Text == "" || TotalSalesAmountTextBox.Text == ""|| ProductIdTextBox.Text == "" || MarketingCampaignDetailsTextBox.Text== "" || SalesDateDateTimePicker.Value == DateTimePicker.MinimumDateTime)
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Delete from [Sales Table]where SSalesOrderID=@primaryKey", con);
                    cmd.Parameters.AddWithValue("@primaryKey", primaryKeyTextBox.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data added");
                    con.Close();
                    showsales();
                    Reset();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void Savebtn1_Click(object sender, EventArgs e)
        {
            if (CustomerIdtextbox.Text==""|| CustomerNametextbox.Text==""|| ContactInfotextbox.Text==""|| SalesorderIdTextBox.Text == "" || QuantitySoldTextBox.Text=="" || UnitPriceTextBox.Text=="" || TotalSalesAmountTextBox.Text=="" || ProductIdTextBox.Text == "" || MarketingCampaignDetailsTextBox.Text=="" || SalesDateDateTimePicker.Value == DateTimePicker.MinimumDateTime)
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd= new SqlCommand("Insert into [Sales Table](CustomerId,CustomerName,ContactInfo,SalesorderId,QuantitySold,UnitPrice,TotalSalesAmount,ProductId,MarketingCampaignDetails,Date) values (@CustomerId,@CustomerName,@ContactInfo,@SalesorderId,@QuantitySold,@UnitPrice,@TotalSalesAmount,@ProductId,@MarketingCampaignDetails,@Date)", con);
                    cmd.Parameters.AddWithValue("@CustomerId", CustomerIdtextbox.Text);
                    cmd.Parameters.AddWithValue("@CustomerName", CustomerNametextbox.Text);
                    cmd.Parameters.AddWithValue("@ContactInfo", ContactInfotextbox.Text);
                    cmd.Parameters.AddWithValue("@SalesorderId", SalesorderIdTextBox.Text);
                    cmd.Parameters.AddWithValue("@QuantitySold", QuantitySoldTextBox.Text);
                    cmd.Parameters.AddWithValue("@UnitPrice", UnitPriceTextBox.Text);
                    cmd.Parameters.AddWithValue("@TotalSalesAmount", TotalSalesAmountTextBox.Text);
                    cmd.Parameters.AddWithValue("@ProductId", ProductIdTextBox.Text);
                    cmd.Parameters.AddWithValue("@MarketingCampaignDetails", MarketingCampaignDetailsTextBox.Text);
                    cmd.Parameters.AddWithValue("@Date", SalesDateDateTimePicker.Value);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data added");
                    con.Close();
                    showsales();
                    Reset();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }

        int key = 0;
        private void SalesandMarketingDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                // Assuming SupplierID is stored in the first column (index 0) of the DataGridView
                string CustomerId = SalesandMarketingDGV.Rows[e.RowIndex].Cells[1].Value.ToString();
                string CustomerName = SalesandMarketingDGV.Rows[e.RowIndex].Cells[8].Value.ToString();
                string ContactInfo = SalesandMarketingDGV.Rows[e.RowIndex].Cells[9].Value.ToString();
                string SalesorderId = SalesandMarketingDGV.Rows[e.RowIndex].Cells[7].Value.ToString();
                string QuantitySold = SalesandMarketingDGV.Rows[e.RowIndex].Cells[3].Value.ToString();
                string UnitPrice = SalesandMarketingDGV.Rows[e.RowIndex].Cells[4].Value.ToString();
                string TotalSalesAmount = SalesandMarketingDGV.Rows[e.RowIndex].Cells[5].Value.ToString();
                string ProductId = SalesandMarketingDGV.Rows[e.RowIndex].Cells[2].Value.ToString();
                string MarketingCampaignDetails = SalesandMarketingDGV.Rows[e.RowIndex].Cells[6].Value.ToString();
                string Date = SalesandMarketingDGV.Rows[e.RowIndex].Cells[10].Value.ToString();
                string SSalesorderId = SalesandMarketingDGV.Rows[e.RowIndex].Cells[0].Value.ToString();

                CustomerIdtextbox.Text = CustomerId;
                CustomerNametextbox.Text = CustomerName;
                ContactInfotextbox.Text = ContactInfo;
                SalesorderIdTextBox.Text = SalesorderId;
                QuantitySoldTextBox.Text = QuantitySold;
                UnitPriceTextBox.Text = UnitPrice;
                SalesDateDateTimePicker.Value = DateTime.Parse(Date);
                TotalSalesAmountTextBox.Text = TotalSalesAmount;
                ProductIdTextBox.Text = ProductId;
                MarketingCampaignDetailsTextBox.Text = MarketingCampaignDetails;
                primaryKeyTextBox.Text = SSalesorderId;


            }
        }

        private void Editbtn_Click(object sender, EventArgs e)
        {
            if (CustomerIdtextbox.Text == "" || CustomerNametextbox.Text == "" || ContactInfotextbox.Text == "" || SalesorderIdTextBox.Text == "" || QuantitySoldTextBox.Text == "" || UnitPriceTextBox.Text == ""  || TotalSalesAmountTextBox.Text == "" || ProductIdTextBox.Text == "" || MarketingCampaignDetailsTextBox.Text == "" || SalesDateDateTimePicker.Value == DateTimePicker.MinimumDateTime)
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Update [Sales Table] set CustomerId=@CustomerId,CustomerName=@CustomerName,ContactInfo=@ContactInfo,SalesorderId=@SalesorderId,QuantitySold=@QuantitySold,UnitPrice=@UnitPrice,TotalSalesAmount=@TotalSalesAmount,ProductId=@ProductId,MarketingCampaignDetails=@MarketingCampaignDetails where SSalesorderId=@primaryKey", con);
                    cmd.Parameters.AddWithValue("@CustomerId", CustomerIdtextbox.Text);
                    cmd.Parameters.AddWithValue("@CustomerName", CustomerNametextbox.Text);
                    cmd.Parameters.AddWithValue("@ContactInfo", ContactInfotextbox.Text);
                    cmd.Parameters.AddWithValue("@SalesorderId", SalesorderIdTextBox.Text);
                    cmd.Parameters.AddWithValue("@QuantitySold", QuantitySoldTextBox.Text);
                    cmd.Parameters.AddWithValue("@UnitPrice", UnitPriceTextBox.Text);
                    cmd.Parameters.AddWithValue("@TotalSalesAmount", TotalSalesAmountTextBox.Text);
                    cmd.Parameters.AddWithValue("@ProductId", ProductIdTextBox.Text);
                    cmd.Parameters.AddWithValue("@MarketingCampaignDetails", MarketingCampaignDetailsTextBox.Text);
                    cmd.Parameters.AddWithValue("@Date", SalesDateDateTimePicker.Value);
                    cmd.Parameters.AddWithValue("@primaryKey", primaryKeyTextBox.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data added");
                    con.Close();
                    showsales();
                    Reset();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Home obj = new Home();
            obj.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            InventoryManagement obj = new InventoryManagement();
            obj.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            SalesandMarketing obj = new SalesandMarketing();
            obj.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            CropManagement obj = new CropManagement();
            obj.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            SupplyChainManagement obj = new SupplyChainManagement();
            obj.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            FinancialAnalysis obj = new FinancialAnalysis();
            obj.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            EmployeeManagement obj = new EmployeeManagement();
            obj.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            QualityControl obj = new QualityControl();
            obj.Show();
            this.Hide();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            EquipmentMaintenance obj = new EquipmentMaintenance();
            obj.Show();
            this.Hide();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            Login obj = new Login();
            obj.Show();
            this.Hide();
        }
    }
}
