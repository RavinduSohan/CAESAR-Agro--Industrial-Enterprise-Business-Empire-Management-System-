﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Try_01__Agro_Industrial_enterprise_management_system
{
    public partial class FinancialAnalysis : Form
    {
        public FinancialAnalysis()
        {
            InitializeComponent();
            showfinance();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""F:\favo\New folder44\New folder\Agr-Industrial Enterprise Management System.mdf"";Integrated Security=True;Connect Timeout=30");

        private void showfinance()
        {
            con.Open();
            string Query = "Select * from [FinancialData Table]";
            SqlDataAdapter sda = new SqlDataAdapter(Query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            FinancialAnalysisDGV.DataSource = ds.Tables[0];
            con.Close();
        }

        private void Reset()
        {
            FinancialYearTextBox.Text = "";
            RevenueTextBox.Text = "";
            ExpensesTextBox.Text = "";
            ProfitTextBox.Text = "";
            BudgetAllocationTextBox.Text = "";
            FinancialRatiosTextBox.Text = "";
            CashFlowStatementTextBox.Text = "";
        }
        private void Form6_Load(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void Savebtn_Click(object sender, EventArgs e)
        {
            if (FinancialYearTextBox.Text==""|| RevenueTextBox.Text==""|| ExpensesTextBox.Text==""|| ProfitTextBox.Text==""|| BudgetAllocationTextBox.Text==""|| FinancialRatiosTextBox.Text=="" || CashFlowStatementTextBox.Text=="")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Insert into [FinancialData Table](FinancialYear,Revenue,Expenses,Profit,BudgetAllocation,FinancialRatios,CashFlowStatement) values (@FinancialYear,@Revenue,@Expenses,@Profit,@BudgetAllocation,@FinancialRatios,@CashFlowStatement)",con);
                    cmd.Parameters.AddWithValue("@FinancialYear", FinancialYearTextBox.Text);
                    cmd.Parameters.AddWithValue("@Revenue", RevenueTextBox.Text);
                    cmd.Parameters.AddWithValue("@Expenses", ExpensesTextBox.Text);
                    cmd.Parameters.AddWithValue("@Profit", ProfitTextBox.Text);
                    cmd.Parameters.AddWithValue("@BudgetAllocation", BudgetAllocationTextBox.Text);
                    cmd.Parameters.AddWithValue("@FinancialRatios", FinancialRatiosTextBox.Text);
                    cmd.Parameters.AddWithValue("@CashFlowStatement", CashFlowStatementTextBox.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Added!");
                    con.Close();
                    showfinance();
                    Reset();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        int key = 0;

        private void FinancialAnalysisDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                // Assuming SupplierID is stored in the first column (index 0) of the DataGridView
                string FinancialYear = FinancialAnalysisDGV.Rows[e.RowIndex].Cells[0].Value.ToString();
                string Revenue = FinancialAnalysisDGV.Rows[e.RowIndex].Cells[1].Value.ToString();
                string Expenses = FinancialAnalysisDGV.Rows[e.RowIndex].Cells[2].Value.ToString();
                string Profit = FinancialAnalysisDGV.Rows[e.RowIndex].Cells[3].Value.ToString();
                string BudgetAllocation = FinancialAnalysisDGV.Rows[e.RowIndex].Cells[5].Value.ToString();
                string FinancialRatios = FinancialAnalysisDGV.Rows[e.RowIndex].Cells[6].Value.ToString();
                string sCashFlowStatement = FinancialAnalysisDGV.Rows[e.RowIndex].Cells[4].Value.ToString();
                string FFinancialYear = FinancialAnalysisDGV.Rows[e.RowIndex].Cells[7].Value.ToString();



                FinancialYearTextBox.Text = FFinancialYear;
                RevenueTextBox.Text = Revenue;
                ExpensesTextBox.Text = Expenses;
                ProfitTextBox.Text = Profit;
                BudgetAllocationTextBox.Text = BudgetAllocation;
                FinancialRatiosTextBox.Text = FinancialRatios;
                CashFlowStatementTextBox.Text = sCashFlowStatement;
                primaryKeyTextBox.Text = FinancialYear;

              
               


            }
        }

        private string ConvertToString(object value)
        {
            return value?.ToString() ?? string.Empty;
        }

       


        private void Editbtn_Click(object sender, EventArgs e)
        {
            if (FinancialYearTextBox.Text == "" || RevenueTextBox.Text == "" || ExpensesTextBox.Text == "" || ProfitTextBox.Text == "" || BudgetAllocationTextBox.Text == "" || FinancialRatiosTextBox.Text == "" || CashFlowStatementTextBox.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Update [FinancialData Table] set FinancialYear=@FinancialYear,Revenue=@Revenue,Expenses=@Expenses,Profit=@Profit,BudgetAllocation=@BudgetAllocation,FinancialRatios=@FinancialRatios,CashFlowStatement=@CashFlowStatement where FFinancialYear= @primaryKey", con);
                    cmd.Parameters.AddWithValue("@FinancialYear", FinancialYearTextBox.Text);
                    cmd.Parameters.AddWithValue("@Revenue", RevenueTextBox.Text);
                    cmd.Parameters.AddWithValue("@Expenses", ExpensesTextBox.Text);
                    cmd.Parameters.AddWithValue("@Profit", ProfitTextBox.Text);
                    cmd.Parameters.AddWithValue("@BudgetAllocation", BudgetAllocationTextBox.Text);
                    cmd.Parameters.AddWithValue("@FinancialRatios", FinancialRatiosTextBox.Text);
                    cmd.Parameters.AddWithValue("@CashFlowStatement", CashFlowStatementTextBox.Text);
                    cmd.Parameters.AddWithValue("@primaryKey", primaryKeyTextBox.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Updated!");
                    con.Close();
                    showfinance();
                    Reset();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void Deletebtn_Click(object sender, EventArgs e)
        {
            if (FinancialYearTextBox.Text == "" || RevenueTextBox.Text == "" || ExpensesTextBox.Text == "" || ProfitTextBox.Text == "" || BudgetAllocationTextBox.Text == "" || FinancialRatiosTextBox.Text == "" || CashFlowStatementTextBox.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Delete from [FinancialData Table] where FFinancialYear=@primaryKey", con);
                    cmd.Parameters.AddWithValue("@primaryKey", primaryKeyTextBox.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Deleted!");
                    con.Close();
                    showfinance();
                    Reset();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Home obj = new Home();
            obj.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            InventoryManagement obj = new InventoryManagement();
            obj.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            SalesandMarketing obj = new SalesandMarketing();
            obj.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            CropManagement obj = new CropManagement();
            obj.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            SupplyChainManagement obj = new SupplyChainManagement();
            obj.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            FinancialAnalysis obj = new FinancialAnalysis();
            obj.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            EmployeeManagement obj = new EmployeeManagement();
            obj.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            QualityControl obj = new QualityControl();
            obj.Show();
            this.Hide();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            EquipmentMaintenance obj = new EquipmentMaintenance();
            obj.Show();
            this.Hide();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            Login obj=new Login();
            obj.Show();
            this.Hide();
        }
    }
}
