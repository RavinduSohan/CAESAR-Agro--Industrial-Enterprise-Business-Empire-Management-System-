﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Try_01__Agro_Industrial_enterprise_management_system
{
    public partial class InventoryManagement : Form
    {
        public InventoryManagement()
        {
            InitializeComponent();
            showinventory();
        }

        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""F:\favo\study stuff\agro\Agr-Industrial Enterprise Management System.mdf"";Integrated Security=True;Connect Timeout=30";
       //SqlConnection Con = new SqlConnection(connectionString);

        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""F:\favo\New folder44\New folder\Agr-Industrial Enterprise Management System.mdf"";Integrated Security=True;Connect Timeout=30");
        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

         private void showinventory()
        {
            Con.Open();
            String Query = "Select * from [Items Table]";
            SqlDataAdapter sda = new SqlDataAdapter(Query, Con);
            SqlCommandBuilder builder= new SqlCommandBuilder(sda);
            var ds= new DataSet();
            sda.Fill(ds);
            InventoryDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void Reset()
        {
            ItemIDTextBox.Text = "";
            ItemNameTextBox.Text = "";
            DescriptionTextBox.Text = "";
            SupplierInformationTextBox.Text = "";
            PurchasePriceTextBox.Text = "";
            QuantityOnHandTextBox.Text = "";
            UnitOfMeasureTextBox.Text = "";
            StorageLocationTextBox.Text = "";
            DateOfPurchaseDateTimePicker.Value = DateTimePicker.MinimumDateTime;
        }
        private void SaveBtn_Click(object sender, EventArgs e)
        {
            if(ItemIDTextBox.Text==""|| ItemNameTextBox.Text==""|| DescriptionTextBox.Text==""|| SupplierInformationTextBox.Text==""|| PurchasePriceTextBox.Text==""|| QuantityOnHandTextBox.Text==""|| UnitOfMeasureTextBox.Text==""|| StorageLocationTextBox.Text == "" || DateOfPurchaseDateTimePicker.Value == DateTimePicker.MinimumDateTime)
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                Con.Open();
                    SqlCommand cmd = new SqlCommand("Insert into [Items Table](ItemID,ItemName, Description, QuantityOnHand, UnitOfMeasure, ISupplierID, PurchasePrice, DateOfPurchase, StorageLocation) values(@ItemID,@ItemName, @Description, @QuantityOnHand, @UnitOfMeasure, @ISupplierID, @PurchasePrice, @DateOfPurchase, @StorageLocation)", Con);
                    cmd.Parameters.AddWithValue("@ItemID", ItemIDTextBox.Text);
                    cmd.Parameters.AddWithValue("@ItemName", ItemNameTextBox.Text);
                    cmd.Parameters.AddWithValue("@Description", DescriptionTextBox.Text);
                    cmd.Parameters.AddWithValue("@QuantityOnHand", QuantityOnHandTextBox.Text);
                    cmd.Parameters.AddWithValue("@UnitOfMeasure", UnitOfMeasureTextBox.Text);
                    cmd.Parameters.AddWithValue("@PurchasePrice", PurchasePriceTextBox.Text);
                    cmd.Parameters.AddWithValue("@DateOfPurchase", DateOfPurchaseDateTimePicker.Value);
                    cmd.Parameters.AddWithValue("@StorageLocation", StorageLocationTextBox.Text);
                    cmd.Parameters.AddWithValue("@ISupplierID", SupplierInformationTextBox.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Added");
                    Con.Close();
                    showinventory();
                    Reset();
                }
                catch(Exception ex) 
                { 
                MessageBox.Show(ex.Message);
                }
            }
        }
        int key = 0;
        /*
        private void InventoryDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                // Assuming SupplierID is stored in the first column (index 0) of the DataGridView
                string IItemID = InventoryDGV.Rows[e.RowIndex].Cells[0].Value.ToString();
                string ItemName = InventoryDGV.Rows[e.RowIndex].Cells[1].Value.ToString();
                string Description = InventoryDGV.Rows[e.RowIndex].Cells[2].Value.ToString();
                string QuantityOnHand = InventoryDGV.Rows[e.RowIndex].Cells[3].Value.ToString();
                string UnitOfMeasure = InventoryDGV.Rows[e.RowIndex].Cells[4].Value.ToString();
                string ISupplierID = InventoryDGV.Rows[e.RowIndex].Cells[5].Value.ToString();
                string PurchasePrice = InventoryDGV.Rows[e.RowIndex].Cells[6].Value.ToString();
                string DateOfPurchase = InventoryDGV.Rows[e.RowIndex].Cells[7].Value.ToString();
                string StorageLocation = InventoryDGV.Rows[e.RowIndex].Cells[8].Value.ToString();
                string ItemID = InventoryDGV.Rows[e.RowIndex].Cells[9].Value.ToString();

                ItemIDTextBox.Text = ItemID;
                ItemNameTextBox.Text = ItemName;
                DescriptionTextBox.Text = Description;
                QuantityOnHandTextBox.Text = QuantityOnHand;
                UnitOfMeasureTextBox.Text = UnitOfMeasure;
                SupplierInformationTextBox.Text = ISupplierID;
                PurchasePriceTextBox.Text = PurchasePrice;
                DateOfPurchaseDateTimePicker.Value = DateTime.Parse(DateOfPurchase);
                StorageLocationTextBox.Text = StorageLocation;
                primaryKeyTextBox.Text = IItemID;





            }
        }
        */
        

        private void EditBtn_Click(object sender, EventArgs e)
        {
            if (ItemIDTextBox.Text == "" || ItemNameTextBox.Text == "" || DescriptionTextBox.Text == "" || SupplierInformationTextBox.Text == "" || PurchasePriceTextBox.Text == "" || QuantityOnHandTextBox.Text == "" || UnitOfMeasureTextBox.Text == "" || StorageLocationTextBox.Text == "" || DateOfPurchaseDateTimePicker.Value == DateTimePicker.MinimumDateTime)
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("Update [Items Table] set ItemID=@ItemID,ItemName=@ItemName, Description=@Description, QuantityOnHand=@QuantityOnHand, UnitOfMeasure=@UnitOfMeasure, ISupplierID=@ISupplierID, PurchasePrice=@PurchasePrice, DateOfPurchase=@DateOfPurchase, StorageLocation=@StorageLocation Where IItemID=@primaryKey", Con);
                    cmd.Parameters.AddWithValue("@ItemID", ItemIDTextBox.Text);
                    cmd.Parameters.AddWithValue("@ItemName", ItemNameTextBox.Text);
                    cmd.Parameters.AddWithValue("@Description", DescriptionTextBox.Text);
                    cmd.Parameters.AddWithValue("@QuantityOnHand", QuantityOnHandTextBox.Text);
                    cmd.Parameters.AddWithValue("@UnitOfMeasure", UnitOfMeasureTextBox.Text);
                    cmd.Parameters.AddWithValue("@PurchasePrice", PurchasePriceTextBox.Text);
                    cmd.Parameters.AddWithValue("@DateOfPurchase", DateOfPurchaseDateTimePicker.Value);
                    cmd.Parameters.AddWithValue("@StorageLocation", StorageLocationTextBox.Text);
                    cmd.Parameters.AddWithValue("@ISupplierID", SupplierInformationTextBox.Text);
                    cmd.Parameters.AddWithValue("@primaryKey", primaryKeyTextBox.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Updated");
                    Con.Close();
                    showinventory();
                    Reset();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            if (key==0)
            {
                MessageBox.Show("Select Inventory Row");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("Delete from [Items Table] Where IItemID=@primaryKey", Con);
                    cmd.Parameters.AddWithValue("@primaryKey", primaryKeyTextBox.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Inventory Deleted!");
                    Con.Close();
                    showinventory();
                    Reset();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            SalesandMarketing obj = new SalesandMarketing();
            obj.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            CropManagement obj = new CropManagement();
            obj.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            SupplyChainManagement obj = new SupplyChainManagement();
            obj.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            FinancialAnalysis obj = new FinancialAnalysis();
            obj.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            EmployeeManagement obj = new EmployeeManagement();
            obj.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            QualityControl obj = new QualityControl();
            obj.Show();
            this.Hide();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            EquipmentMaintenance obj = new EquipmentMaintenance();
            obj.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            InventoryManagement obj = new InventoryManagement();
            obj.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Home obj= new Home();
            obj.Show();
            this.Hide();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void InventoryDGV_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                // Assuming SupplierID is stored in the first column (index 0) of the DataGridView
                string IItemID = InventoryDGV.Rows[e.RowIndex].Cells[0].Value.ToString();
                string ItemName = InventoryDGV.Rows[e.RowIndex].Cells[1].Value.ToString();
                string Description = InventoryDGV.Rows[e.RowIndex].Cells[2].Value.ToString();
                string QuantityOnHand = InventoryDGV.Rows[e.RowIndex].Cells[3].Value.ToString();
                string UnitOfMeasure = InventoryDGV.Rows[e.RowIndex].Cells[4].Value.ToString();
                string ISupplierID = InventoryDGV.Rows[e.RowIndex].Cells[5].Value.ToString();
                string PurchasePrice = InventoryDGV.Rows[e.RowIndex].Cells[6].Value.ToString();
                string DateOfPurchase = InventoryDGV.Rows[e.RowIndex].Cells[7].Value.ToString();
                string StorageLocation = InventoryDGV.Rows[e.RowIndex].Cells[8].Value.ToString();
                string ItemID = InventoryDGV.Rows[e.RowIndex].Cells[9].Value.ToString();

                ItemIDTextBox.Text = ItemID;
                ItemNameTextBox.Text = ItemName;
                DescriptionTextBox.Text = Description;
                QuantityOnHandTextBox.Text = QuantityOnHand;
                UnitOfMeasureTextBox.Text = UnitOfMeasure;
                SupplierInformationTextBox.Text = ISupplierID;
                PurchasePriceTextBox.Text = PurchasePrice;
                DateOfPurchaseDateTimePicker.Value = DateTime.Parse(DateOfPurchase);
                StorageLocationTextBox.Text = StorageLocation;
                primaryKeyTextBox.Text = IItemID;





            }
        }

        private void label9_Click(object sender, EventArgs e)
        {
            Login obj=new Login();
            obj.Show();
            this.Hide();
        }
    }
}
