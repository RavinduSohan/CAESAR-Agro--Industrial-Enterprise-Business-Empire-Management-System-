﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Try_01__Agro_Industrial_enterprise_management_system
{
    public partial class CropManagement : Form
    {
        public CropManagement()
        {
            InitializeComponent();
            showcrops();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""F:\favo\New folder44\New folder\Agr-Industrial Enterprise Management System.mdf"";Integrated Security=True;Connect Timeout=30");

        private void showcrops()
        {
            con.Open();
            string Query = "Select * from [Crops Table]";
            SqlDataAdapter sda = new SqlDataAdapter(Query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            CropManagementDGV.DataSource = ds.Tables[0];
            con.Close();
        }
        private void Reset()
        {
            CropIdTextBox.Text = "";
            CropNameTextBox.Text = "";
            ExpectedYieldTextBox.Text = "";
            PestControlMeasuresTextBox.Text = "";
            SoilConditionsTextBox.Text = "";
            PlantingDateDateTimePicker.Value = DateTimePicker.MinimumDateTime;
            HarvestDateDateTimePicker.Value = DateTimePicker.MinimumDateTime;
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void Savebtn_Click(object sender, EventArgs e)
        {
            if (CropIdTextBox.Text==""|| CropNameTextBox.Text==""|| ExpectedYieldTextBox.Text==""|| PestControlMeasuresTextBox.Text==""|| SoilConditionsTextBox.Text==""|| PlantingDateDateTimePicker.Value == DateTimePicker.MinimumDateTime|| HarvestDateDateTimePicker.Value == DateTimePicker.MinimumDateTime)
            {
                MessageBox.Show("Missing Information!");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Insert into [Crops Table](CropId,CropName,ExpectedYield,PestControlMeasures,SoilCondition,PlantingDate,HarvestingDate) values (@CropId,@CropName,@ExpectedYield,@PestControlMeasures,@SoilCondition,@PlantingDate,@HarvestingDate)", con);
                    cmd.Parameters.AddWithValue("@CropId", CropIdTextBox.Text);
                    cmd.Parameters.AddWithValue("@CropName", CropNameTextBox.Text);
                    cmd.Parameters.AddWithValue("@ExpectedYield", ExpectedYieldTextBox.Text);
                    cmd.Parameters.AddWithValue("@PestControlMeasures", PestControlMeasuresTextBox.Text);
                    cmd.Parameters.AddWithValue("@SoilCondition", SoilConditionsTextBox.Text);
                    cmd.Parameters.AddWithValue("@PlantingDate", PlantingDateDateTimePicker.Value);
                    cmd.Parameters.AddWithValue("@HarvestingDate", HarvestDateDateTimePicker.Value);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data added!");
                    con.Close();
                    showcrops();
                    Reset();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                 
            }
        }

        int key = 0;

        private void CropManagementDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
               
                string CCropID = CropManagementDGV.Rows[e.RowIndex].Cells[0].Value.ToString();
                string CropName = CropManagementDGV.Rows[e.RowIndex].Cells[1].Value.ToString();
                string PlantingDate = CropManagementDGV.Rows[e.RowIndex].Cells[2].Value.ToString();
                string HarvestingDate = CropManagementDGV.Rows[e.RowIndex].Cells[3].Value.ToString();
                string ExpectedYield = CropManagementDGV.Rows[e.RowIndex].Cells[4].Value.ToString();
                string PestControlMeasure = CropManagementDGV.Rows[e.RowIndex].Cells[5].Value.ToString();
                string SoilCondition = CropManagementDGV.Rows[e.RowIndex].Cells[6].Value.ToString();
           
                string CropID = CropManagementDGV.Rows[e.RowIndex].Cells[8].Value.ToString();



                CropIdTextBox.Text = CropID;
                CropNameTextBox.Text = CropName;
                ExpectedYieldTextBox.Text = ExpectedYield;
                PestControlMeasuresTextBox.Text = PestControlMeasure;
                SoilConditionsTextBox.Text = SoilCondition;
                primaryKeyTextBox.Text = CCropID;


                PlantingDateDateTimePicker.Value = DateTime.Parse(PlantingDate);
                HarvestDateDateTimePicker.Value = DateTime.Parse(HarvestingDate);

            }
        }
        
     
        
        private void Editbtn_Click(object sender, EventArgs e)
        {
            if (CropIdTextBox.Text == "" || CropNameTextBox.Text == "" || ExpectedYieldTextBox.Text == "" || PestControlMeasuresTextBox.Text == "" || SoilConditionsTextBox.Text == "" || PlantingDateDateTimePicker.Value == DateTimePicker.MinimumDateTime || HarvestDateDateTimePicker.Value == DateTimePicker.MinimumDateTime)
            {
                MessageBox.Show("Missing Information!");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Update [Crops Table] set CropId=@CropId,CropName=@CropName,ExpectedYield=@ExpectedYield,PestControlMeasures=@PestControlMeasures,SoilCondition=@SoilCondition,PlantingDate=@PlantingDate,HarvestingDate=@HarvestingDate where CCropID= @primaryKey", con);
                    cmd.Parameters.AddWithValue("@CropId", CropIdTextBox.Text);
                    cmd.Parameters.AddWithValue("@CropName", CropNameTextBox.Text);
                    cmd.Parameters.AddWithValue("@ExpectedYield", ExpectedYieldTextBox.Text);
                    cmd.Parameters.AddWithValue("@PestControlMeasures", PestControlMeasuresTextBox.Text);
                    cmd.Parameters.AddWithValue("@SoilCondition", SoilConditionsTextBox.Text);
                    cmd.Parameters.AddWithValue("@PlantingDate", PlantingDateDateTimePicker.Value);
                    cmd.Parameters.AddWithValue("@HarvestingDate", HarvestDateDateTimePicker.Value);
                    cmd.Parameters.AddWithValue("@primaryKey", primaryKeyTextBox.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data added!");
                    con.Close();
                    showcrops();
                    Reset();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            if (CropIdTextBox.Text == "" || CropNameTextBox.Text == "" || ExpectedYieldTextBox.Text == "" || PestControlMeasuresTextBox.Text == "" || SoilConditionsTextBox.Text == "" || PlantingDateDateTimePicker.Value == DateTimePicker.MinimumDateTime || HarvestDateDateTimePicker.Value == DateTimePicker.MinimumDateTime)
            {
                MessageBox.Show("Missing Information!");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Delete from [Crops Table] where CCropID= @primaryKey", con);
                    cmd.Parameters.AddWithValue("@primaryKey", primaryKeyTextBox.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data added!");
                    con.Close();
                    showcrops();
                    Reset();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void label1_Click_1(object sender, EventArgs e)
        {
            Home obj = new Home();
            obj.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            InventoryManagement obj = new InventoryManagement();
            obj.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            SalesandMarketing obj = new SalesandMarketing();
            obj.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            CropManagement obj = new CropManagement();
            obj.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            SupplyChainManagement obj = new SupplyChainManagement();
            obj.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            FinancialAnalysis obj = new FinancialAnalysis();
            obj.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            EmployeeManagement obj = new EmployeeManagement();
            obj.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            QualityControl obj = new QualityControl();
            obj.Show();
            this.Hide();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            EquipmentMaintenance obj = new EquipmentMaintenance();
            obj.Show();
            this.Hide();
        }

        private void ExpectedYieldTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {
            Login obj=new Login();
            obj.Show();
            this.Hide();
        }
    }
}
