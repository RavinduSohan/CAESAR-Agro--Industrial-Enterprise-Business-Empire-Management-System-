﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Try_01__Agro_Industrial_enterprise_management_system
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
            countcustomers();
            countcrops();
            countinspections();
            countemployees();
            countsalaries();
            countprofit();
            countinventories();
            countfinancial();
            countequipments();
            countbudget();
            counttotalsales();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""F:\favo\New folder44\New folder\Agr-Industrial Enterprise Management System.mdf"";Integrated Security=True;Connect Timeout=30");

        private void countcustomers()
        {
            con.Open();
            SqlDataAdapter sda= new SqlDataAdapter("Select Count(*) from [Sales Table]",con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            Customerslbl.Text = dt.Rows[0][0].ToString();
            con.Close();
        }

        private void countcrops()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) from [Crops Table]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            Cropslbl.Text = dt.Rows[0][0].ToString();
            con.Close();
        }

        private void countinspections()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) from [Inspection Table]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            Inspectionslbl.Text = dt.Rows[0][0].ToString();
            con.Close();
        }

        private void countemployees()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) from [Employees Table]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            Employeeslbl.Text = dt.Rows[0][0].ToString();
            con.Close();
        }

        private void countprofit()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select Sum(Profit) from [FinancialData Table]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            Profitlbl.Text = "RS."+dt.Rows[0][0].ToString();
            con.Close();
        }

        private void countsalaries()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select Sum(Salary) from [Employees Table]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            Salarieslbl.Text = "RS." + dt.Rows[0][0].ToString();
            con.Close();
        }

        private void countequipments()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) from [Items Table]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            Equipmentslbl.Text = dt.Rows[0][0].ToString();
            con.Close();
        }

        private void countfinancial()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) from [FinancialData Table]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            Financiallbl.Text = dt.Rows[0][0].ToString();
            con.Close();
        }

        private void countinventories()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) from [Equipment Table]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            Inventorieslbl.Text = dt.Rows[0][0].ToString();
            con.Close();
        }

        private void counttotalsales()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select Sum(TotalSalesAmount) from [Sales Table]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            Totalsaleslbl.Text = "RS." + dt.Rows[0][0].ToString();
            con.Close();
        }

        private void countbudget()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select Sum(BudgetAllocation) from [FinancialData Table]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            Budgetlbl.Text = "RS." + dt.Rows[0][0].ToString();
            con.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            Home obj = new Home();
            obj.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            InventoryManagement obj = new InventoryManagement();
            obj.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            SalesandMarketing obj = new SalesandMarketing();
            obj.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            CropManagement obj = new CropManagement();
            obj.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            SupplyChainManagement obj = new SupplyChainManagement();
            obj.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            FinancialAnalysis obj = new FinancialAnalysis();
            obj.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            EmployeeManagement obj = new EmployeeManagement();
            obj.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            QualityControl obj = new QualityControl();
            obj.Show();
            this.Hide();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            EquipmentMaintenance obj = new EquipmentMaintenance();
            obj.Show();
            this.Hide();
        }

        private void Profitlbl_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {
            Login obj=new Login();
            obj.Show();
            this.Hide();
        }

        private void Totalsaleslbl_Click(object sender, EventArgs e)
        {

        }
    }
}
