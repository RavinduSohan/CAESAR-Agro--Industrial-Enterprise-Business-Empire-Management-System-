﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography;

namespace Try_01__Agro_Industrial_enterprise_management_system
{
    public partial class EquipmentMaintenance : Form
    {
        public EquipmentMaintenance()
        {
            InitializeComponent();
            showequipment();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""F:\favo\New folder44\New folder\Agr-Industrial Enterprise Management System.mdf"";Integrated Security=True;Connect Timeout=30");

        private void showequipment()
        {
            con.Open();
            string Query = "Select * from [Equipment Table]";
            SqlDataAdapter sda = new SqlDataAdapter(Query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            EquipmentMaintenanceDGV.DataSource = ds.Tables[0];
            con.Close();
        }

        private void Reset()
        {
            EquipmentIdTextBox.Text = "";
            EquipmentNameTextBox.Text = "";
            MaintenanceTypeTextBox.Text = "";
            MaintenanceTechnicianTextBox.Text = "";
            MaintenanceCostTextBox.Text = "";
            MaintenanceScheduleDateTimePicker.Value= DateTimePicker.MinimumDateTime;
            LastMaintenanceDateDateTimePicker.Value= DateTimePicker.MaximumDateTime;
            NextMaintenanceDueDateDateTimePicker.Value = DateTimePicker.MinimumDateTime;   
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (EquipmentIdTextBox.Text==""|| EquipmentNameTextBox.Text==""|| MaintenanceTypeTextBox.Text==""|| MaintenanceTechnicianTextBox.Text=="" || MaintenanceCostTextBox.Text==""|| MaintenanceScheduleDateTimePicker.Value == DateTimePicker.MinimumDateTime || LastMaintenanceDateDateTimePicker.Value == DateTimePicker.MaximumDateTime|| NextMaintenanceDueDateDateTimePicker.Value == DateTimePicker.MinimumDateTime)
            {
                MessageBox.Show("Missing Info!");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Insert into [Equipment Table](EquipmentId,EquipmentName,MaintenanceType,MaintenanceTechnician,MaintenanceCost,MaintenanceSchedule,LastMaintenanceDate,NextMaintenanceDueDate) Values (@EquipmentId,@EquipmentName,@MaintenanceType,@MaintenanceTechnician,@MaintenanceCost,@MaintenanceSchedule,@LastMaintenanceDate,@NextMaintenanceDueDate)", con);
                    cmd.Parameters.AddWithValue("@EquipmentId", EquipmentIdTextBox.Text);
                    cmd.Parameters.AddWithValue("@EquipmentName", EquipmentNameTextBox.Text);
                    cmd.Parameters.AddWithValue("@MaintenanceType", MaintenanceTypeTextBox.Text);
                    cmd.Parameters.AddWithValue("@MaintenanceTechnician", MaintenanceTechnicianTextBox.Text);
                    cmd.Parameters.AddWithValue("@MaintenanceCost", EquipmentIdTextBox.Text);
                    cmd.Parameters.AddWithValue("@MaintenanceSchedule", MaintenanceScheduleDateTimePicker.Value);
                    cmd.Parameters.AddWithValue("@LastMaintenanceDate", LastMaintenanceDateDateTimePicker.Value);
                    cmd.Parameters.AddWithValue("@NextMaintenanceDueDate", NextMaintenanceDueDateDateTimePicker.Value);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Added!");
                    con.Close();
                    showequipment();
                    Reset();
                }
                catch (Exception ex) 
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void Form9_Load(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void Editbtn_Click(object sender, EventArgs e)
        {
            if (EquipmentIdTextBox.Text == "" || EquipmentNameTextBox.Text == "" || MaintenanceTypeTextBox.Text == "" || MaintenanceTechnicianTextBox.Text == "" || MaintenanceCostTextBox.Text == "" || MaintenanceScheduleDateTimePicker.Value == DateTimePicker.MinimumDateTime || LastMaintenanceDateDateTimePicker.Value == DateTimePicker.MaximumDateTime || NextMaintenanceDueDateDateTimePicker.Value == DateTimePicker.MinimumDateTime)
            {
                MessageBox.Show("Missing Info!");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Update [Equipment Table] set EquipmentId=@EquipmentId,EquipmentName=@EquipmentName,MaintenanceType=@MaintenanceType,MaintenanceTechnician=@MaintenanceTechnician,MaintenanceCost=@MaintenanceCost ,MaintenanceSchedule=@MaintenanceSchedule,LastMaintenanceDate=@LastMaintenanceDate,NextMaintenanceDueDate=@NextMaintenanceDueDate Where EEquipmentId=@primaryKey", con);
                    cmd.Parameters.AddWithValue("@EquipmentId", EquipmentIdTextBox.Text);
                    cmd.Parameters.AddWithValue("@EquipmentName", EquipmentNameTextBox.Text);
                    cmd.Parameters.AddWithValue("@MaintenanceType", MaintenanceTypeTextBox.Text);
                    cmd.Parameters.AddWithValue("@MaintenanceTechnician", MaintenanceTechnicianTextBox.Text);
                    cmd.Parameters.AddWithValue("@MaintenanceCost", EquipmentIdTextBox.Text);
                    cmd.Parameters.AddWithValue("@MaintenanceSchedule", MaintenanceScheduleDateTimePicker.Value);
                    cmd.Parameters.AddWithValue("@LastMaintenanceDate", LastMaintenanceDateDateTimePicker.Value);
                    cmd.Parameters.AddWithValue("@NextMaintenanceDueDate", NextMaintenanceDueDateDateTimePicker.Value);
                    cmd.Parameters.AddWithValue("@primaryKey", primaryKeyTextBox.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Updated!");
                    con.Close();
                    showequipment();
                    Reset();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        int key = 0;

        private void EquipmentMaintenanceDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                // Assuming SupplierID is stored in the first column (index 0) of the DataGridView
                string EquipmentId = EquipmentMaintenanceDGV.Rows[e.RowIndex].Cells[0].Value.ToString();
                string EquipmentName = EquipmentMaintenanceDGV.Rows[e.RowIndex].Cells[1].Value.ToString();
                string MaintenanceType = EquipmentMaintenanceDGV.Rows[e.RowIndex].Cells[5].Value.ToString();
                string MaintenanceTechnician = EquipmentMaintenanceDGV.Rows[e.RowIndex].Cells[6].Value.ToString();
                string MaintenanceCost = EquipmentMaintenanceDGV.Rows[e.RowIndex].Cells[7].Value.ToString();

                string MaintenanceSchedule = EquipmentMaintenanceDGV.Rows[e.RowIndex].Cells[2].Value.ToString();
                string LastMaintenanceDate = EquipmentMaintenanceDGV.Rows[e.RowIndex].Cells[3].Value.ToString();
                string NextMaintenanceDueDate = EquipmentMaintenanceDGV.Rows[e.RowIndex].Cells[4].Value.ToString();
                string EEquipmentId = EquipmentMaintenanceDGV.Rows[e.RowIndex].Cells[8].Value.ToString();

                EquipmentIdTextBox.Text = EEquipmentId;
                EquipmentNameTextBox.Text = EquipmentName;
                MaintenanceTypeTextBox.Text = MaintenanceType;
                MaintenanceTechnicianTextBox.Text = MaintenanceTechnician;
                MaintenanceCostTextBox.Text = MaintenanceCost;
                MaintenanceScheduleDateTimePicker.Value = DateTime.Parse(MaintenanceSchedule);
                LastMaintenanceDateDateTimePicker.Value = DateTime.Parse(LastMaintenanceDate);
                NextMaintenanceDueDateDateTimePicker.Value = DateTime.Parse(NextMaintenanceDueDate);
                primaryKeyTextBox.Text = EquipmentId;


            }
        }

        private string ConvertToString(object value)
        {
            return value?.ToString() ?? string.Empty;
        }
        
      




        private void Deletebtn_Click(object sender, EventArgs e)
        {
            if (EquipmentIdTextBox.Text == "" || EquipmentNameTextBox.Text == "" || MaintenanceTypeTextBox.Text == "" || MaintenanceTechnicianTextBox.Text == "" || MaintenanceCostTextBox.Text == "" || MaintenanceScheduleDateTimePicker.Value == DateTimePicker.MinimumDateTime || LastMaintenanceDateDateTimePicker.Value == DateTimePicker.MaximumDateTime || NextMaintenanceDueDateDateTimePicker.Value == DateTimePicker.MinimumDateTime)
            {
                MessageBox.Show("Missing Info!");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Delete from [Equipment Table] Where EEquipmentId=@primaryKey", con);
                    cmd.Parameters.AddWithValue("@primaryKey", primaryKeyTextBox.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Deleted!");
                    con.Close();
                    showequipment();
                    Reset();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Home obj = new Home();
            obj.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            InventoryManagement obj = new InventoryManagement();
            obj.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            SalesandMarketing obj = new SalesandMarketing();
            obj.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            CropManagement obj = new CropManagement();
            obj.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            SupplyChainManagement obj = new SupplyChainManagement();
            obj.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            FinancialAnalysis obj = new FinancialAnalysis();
            obj.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            EmployeeManagement obj = new EmployeeManagement();
            obj.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            QualityControl obj = new QualityControl();
            obj.Show();
            this.Hide();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            EquipmentMaintenance obj = new EquipmentMaintenance();
            obj.Show();
            this.Hide();
        }

        private void MaintenanceCostNumericUpDown_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {
            Login obj = new Login();
            obj.Show();
            this.Hide();
        }
    }
}
