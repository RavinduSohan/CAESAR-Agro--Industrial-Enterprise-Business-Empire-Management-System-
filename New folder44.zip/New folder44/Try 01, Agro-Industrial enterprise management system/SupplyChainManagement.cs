﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Try_01__Agro_Industrial_enterprise_management_system
{
    public partial class SupplyChainManagement : Form
    {
        public SupplyChainManagement()
        {
            InitializeComponent();
            showsupplychain();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""F:\favo\New folder44\New folder\Agr-Industrial Enterprise Management System.mdf"";Integrated Security=True;Connect Timeout=30");

        private void showsupplychain()
        {
            con.Open();
            string Query = "Select * from [Suppliers Table]";
            SqlDataAdapter sda = new SqlDataAdapter(Query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            SupplyChainManagementDGV.DataSource = ds.Tables[0];
            con.Close();
        }

        private void Reset()
        {
            SupplierIdTextBox.Text = "";
            SupplierNameTextBox.Text = "";
            ContactInfoTextBox.Text = "";
            PurchaseOrderIdTextBox.Text = "";
            QuantityOrderTextBox.Text = "";
            ItemIdTextBox.Text = "";
            ShippingDetailsTextBox.Text = "";
            DeliverDateDateTimePicker.Value = DateTimePicker.MinimumDateTime;
        }
        private void Form5_Load(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void Savebtn_Click(object sender, EventArgs e)
        {
            if (SupplierIdTextBox.Text==""|| SupplierNameTextBox.Text==""|| ContactInfoTextBox.Text=="" || PurchaseOrderIdTextBox.Text == ""|| QuantityOrderTextBox.Text==""|| ItemIdTextBox.Text==""|| ShippingDetailsTextBox.Text=="" || DeliverDateDateTimePicker.Value == DateTimePicker.MinimumDateTime)
            {
                MessageBox.Show("Missing information!");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Insert into [Suppliers Table](SupplierId,SupplierName,ContactInfo,PurchaseOrderId,QuantityOrder,ItemId,ShippingDetails,DeliverDate) values (@SupplierId,@SupplierName,@ContactInfo,@PurchaseOrderId,@QuantityOrder,@ItemId,@ShippingDetails,@DeliverDate)", con);
                    cmd.Parameters.AddWithValue("@SupplierId", SupplierIdTextBox.Text);
                    cmd.Parameters.AddWithValue("@SupplierName", SupplierNameTextBox.Text);
                    cmd.Parameters.AddWithValue("@ContactInfo", ContactInfoTextBox.Text);
                    cmd.Parameters.AddWithValue("@PurchaseOrderId", PurchaseOrderIdTextBox.Text);
                    cmd.Parameters.AddWithValue("@QuantityOrder", QuantityOrderTextBox.Text);
                    cmd.Parameters.AddWithValue("@ItemId", ItemIdTextBox.Text);
                    cmd.Parameters.AddWithValue("@ShippingDetails", ShippingDetailsTextBox.Text);
                    cmd.Parameters.AddWithValue("@DeliverDate", DeliverDateDateTimePicker.Value);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data added!");
                    con.Close();
                    showsupplychain();
                    Reset();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        int key = 0;
        private void SupplyChainManagementDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Check if a row is selected and the clicked cell is not a header cell
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                // Assuming SupplierID is stored in the first column (index 0) of the DataGridView
                string supplierID = SupplyChainManagementDGV.Rows[e.RowIndex].Cells[0].Value.ToString();
                string supplierName = SupplyChainManagementDGV.Rows[e.RowIndex].Cells[1].Value.ToString();
                string contactInfo = SupplyChainManagementDGV.Rows[e.RowIndex].Cells[2].Value.ToString();
                string purchasedorderId = SupplyChainManagementDGV.Rows[e.RowIndex].Cells[3].Value.ToString();
                string quantityOrder = SupplyChainManagementDGV.Rows[e.RowIndex].Cells[4].Value.ToString();
                string itemId = SupplyChainManagementDGV.Rows[e.RowIndex].Cells[5].Value.ToString();
                string shippingDetails = SupplyChainManagementDGV.Rows[e.RowIndex].Cells[6].Value.ToString();
                string deliverDate = SupplyChainManagementDGV.Rows[e.RowIndex].Cells[7].Value.ToString();
                string suplierId2 = SupplyChainManagementDGV.Rows[e.RowIndex].Cells[8].Value.ToString();


                SupplierIdTextBox.Text = suplierId2;
                SupplierNameTextBox.Text = supplierName;
                ContactInfoTextBox.Text = contactInfo;
                PurchaseOrderIdTextBox.Text = purchasedorderId;
                QuantityOrderTextBox.Text = quantityOrder;
                ItemIdTextBox.Text = itemId;
                ShippingDetailsTextBox.Text = shippingDetails;
                primaryKeyTextbox.Text = supplierID;

                // Assuming DeliverDate is a DateTimePicker control
                DeliverDateDateTimePicker.Value = DateTime.Parse(deliverDate);

                
            }
        }



        private void Editbtn_Click(object sender, EventArgs e)
        {
           

                if (SupplierIdTextBox.Text == "" || SupplierNameTextBox.Text == "" || ContactInfoTextBox.Text == "" || PurchaseOrderIdTextBox.Text == "" || QuantityOrderTextBox.Text == "" || ItemIdTextBox.Text == "" || ShippingDetailsTextBox.Text == "" )
            {
                MessageBox.Show("Missing information!");
            }
            else
            {
                try
                {
                    
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Update [Suppliers Table] set SupplierId=@SupplierId,SupplierName=@SupplierName,ContactInfo=@ContactInfo,PurchaseOrderId=@PurchaseOrderId,QuantityOrder=@QuantityOrder,ItemId=@ItemId,ShippingDetails=@ShippingDetails  Where SSupplierID=@primaryKey", con);
                   
                    cmd.Parameters.AddWithValue("@SupplierId", SupplierIdTextBox.Text);
                    cmd.Parameters.AddWithValue("@SupplierName", SupplierNameTextBox.Text);
                    cmd.Parameters.AddWithValue("@ContactInfo", ContactInfoTextBox.Text);
                    cmd.Parameters.AddWithValue("@PurchaseOrderId", PurchaseOrderIdTextBox.Text);
                    cmd.Parameters.AddWithValue("@QuantityOrder", QuantityOrderTextBox.Text);
                    cmd.Parameters.AddWithValue("@ItemId", ItemIdTextBox.Text);
                    cmd.Parameters.AddWithValue("@ShippingDetails", ShippingDetailsTextBox.Text);
                    cmd.Parameters.AddWithValue("@primaryKey", primaryKeyTextbox.Text);
                   
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Updated!");
                    con.Close();

                    showsupplychain();

                    Reset();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void Deletebtn_Click(object sender, EventArgs e)
        {
            if (SupplierIdTextBox.Text == "" || SupplierNameTextBox.Text == "" || ContactInfoTextBox.Text == "" || PurchaseOrderIdTextBox.Text == "" || QuantityOrderTextBox.Text == "" || ItemIdTextBox.Text == "" || ShippingDetailsTextBox.Text == "" || DeliverDateDateTimePicker.Value == DateTimePicker.MinimumDateTime)
            {
                MessageBox.Show("Missing information!");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Delete from [Suppliers Table] where SSupplierID=@primaryKey", con);
                    cmd.Parameters.AddWithValue("@primaryKey", primaryKeyTextbox.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Deleted!");
                    con.Close();
                    showsupplychain();
                    Reset();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Home obj = new Home();
            obj.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            InventoryManagement obj = new InventoryManagement();
            obj.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            SalesandMarketing obj = new SalesandMarketing();
            obj.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            CropManagement obj = new CropManagement();
            obj.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            SupplyChainManagement obj = new SupplyChainManagement();
            obj.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            FinancialAnalysis obj = new FinancialAnalysis();
            obj.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            EmployeeManagement obj = new EmployeeManagement();
            obj.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            QualityControl obj = new QualityControl();
            obj.Show();
            this.Hide();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            EquipmentMaintenance obj = new EquipmentMaintenance();
            obj.Show();
            this.Hide();
        }

        private void PurchaseOrderIdNumericUpDown_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {
            Login obj=new Login();
            obj.Show();
            this.Hide();
        }
    }
}
